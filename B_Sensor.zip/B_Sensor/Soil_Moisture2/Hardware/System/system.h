#ifndef HARDWARE_SYSTEM_SYSTEM_H_
#define HARDWARE_SYSTEM_SYSTEM_H_

#include "ch32l103.h"
#include <stdio.h>

#define STK_CTLR    (*(volatile uint32_t *)0xE000F000)
#define STK_CNT     (*(volatile uint32_t *)0xE000F008)
#define STK_CMP     (*(volatile uint32_t *)0xE000F010)

#define SYSTICK_FREQ_HZ     96000000U

void USART1_Printf_Init(void);
void Simple_Delay(u32 ms);

void SysTick_Init(u32 ticks);
u32  GetTick(void);
u32  GetTickDiff(u32 now, u32 last);

void IWDG_Init(void);
void IWDG_Feed(void);

#endif
