#ifndef __LORA_H
#define __LORA_H

#include "../../Peripheral/inc/ch32l103.h"
#include "../System/system.h"
#include <string.h>

#define LORA_M0_PORT                GPIOB
#define LORA_M0_PIN                 GPIO_Pin_0
#define LORA_M1_PORT                GPIOB
#define LORA_M1_PIN                 GPIO_Pin_1

#define LORA_UART_GPIO_PORT         GPIOA
#define LORA_UART_GPIO_CLK          RCC_PB2Periph_GPIOA
#define LORA_UART_TX_PIN            GPIO_Pin_2
#define LORA_UART_RX_PIN            GPIO_Pin_3

#define LORA_RX_BUF_SIZE            256
#define LORA_RX_TIMEOUT_MS          19200000U
#define LORA_TX_GUARD_MS            80U

extern volatile u8 lora_rx_buffer[LORA_RX_BUF_SIZE];
extern volatile u16 lora_rx_len;
extern volatile u8 lora_rx_complete;
extern volatile u8 lora_rx_overflow;
extern volatile u32 lora_last_rx_time;

typedef struct
{
    u8 soil_humidity;
    u8 light_intensity;
    u8 air_humidity;
    s8 air_temperature;
} Sensor_DataTypeDef;

void LoRa_Init(void);
void LoRa_Send_Byte(u8 data);
void LoRa_Send_Buffer(const u8 *buffer, u16 len);
void LoRa_Send_String(const char *str);

u8 LoRa_Receive_Check(void);
u16 LoRa_Read_Buffer(u8 *buffer, u16 max_len);
void LoRa_Clear_Rx(void);
void LoRa_Rx_Timeout_Check(void);
void LoRa_Update_Rx_Time(void);

#endif
