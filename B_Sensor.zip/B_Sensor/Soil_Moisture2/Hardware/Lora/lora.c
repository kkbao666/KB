#include "lora.h"

volatile u8 lora_rx_buffer[LORA_RX_BUF_SIZE];
volatile u16 lora_rx_len = 0;
volatile u8 lora_rx_complete = 0;
volatile u8 lora_rx_overflow = 0;

volatile u32 lora_last_rx_time = 0;

static void simple_delay_ms(u32 ms)
{
    u32 i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 8000; j++)
            __NOP();
}

void LoRa_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_PB2PeriphClockCmd(RCC_PB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = LORA_M0_PIN | LORA_M1_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(LORA_M0_PORT, &GPIO_InitStructure);

    GPIO_ResetBits(LORA_M0_PORT, LORA_M0_PIN);
    GPIO_ResetBits(LORA_M1_PORT, LORA_M1_PIN);
}

void LoRa_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    RCC_PB2PeriphClockCmd(LORA_UART_GPIO_CLK, ENABLE);
    RCC_PB1PeriphClockCmd(RCC_PB1Periph_USART2, ENABLE);

    GPIO_InitStructure.GPIO_Pin = LORA_UART_TX_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(LORA_UART_GPIO_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = LORA_UART_RX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(LORA_UART_GPIO_PORT, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART2, &USART_InitStructure);

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    NVIC_SetPriority(USART2_IRQn, 0);
    NVIC_EnableIRQ(USART2_IRQn);

    USART_Cmd(USART2, ENABLE);
}

void LoRa_Init(void)
{
    LoRa_GPIO_Init();
    LoRa_UART_Init();
    LoRa_Clear_Rx();
    simple_delay_ms(100);
}

void LoRa_Send_Byte(u8 data)
{
    USART_SendData(USART2, data);
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}

void LoRa_Send_Buffer(const u8 *buffer, u16 len)
{
    for(u16 i = 0; i < len; i++)
        LoRa_Send_Byte(buffer[i]);

    while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);
    simple_delay_ms(LORA_TX_GUARD_MS);
}

void LoRa_Send_String(const char *str)
{
    while(*str)
        LoRa_Send_Byte((u8)*str++);

    while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);
    simple_delay_ms(LORA_TX_GUARD_MS);
}

u8 LoRa_Receive_Check(void)
{
    return lora_rx_complete || lora_rx_overflow;
}

u16 LoRa_Read_Buffer(u8 *buffer, u16 max_len)
{
    u16 len;

    NVIC_DisableIRQ(USART2_IRQn);
    len = lora_rx_len;
    if(len > max_len)
        len = max_len;

    for(u16 i = 0; i < len; i++)
        buffer[i] = lora_rx_buffer[i];

    lora_rx_len = 0;
    lora_rx_complete = 0;
    lora_rx_overflow = 0;
    lora_last_rx_time = 0;
    NVIC_EnableIRQ(USART2_IRQn);

    return len;
}

void LoRa_Clear_Rx(void)
{
    NVIC_DisableIRQ(USART2_IRQn);
    lora_rx_len = 0;
    lora_rx_complete = 0;
    lora_rx_overflow = 0;
    lora_last_rx_time = 0;
    NVIC_EnableIRQ(USART2_IRQn);
}

void LoRa_Update_Rx_Time(void)
{
    lora_last_rx_time = GetTick();
}

static u8 LoRa_Rx_Is_Agri_Prefix(void)
{
    const char prefix[] = "$AGRI";

    if(lora_rx_len == 0U) return 0;
    if(lora_rx_len > 5U)
    {
        return (lora_rx_buffer[0] == '$') &&
               (lora_rx_buffer[1] == 'A') &&
               (lora_rx_buffer[2] == 'G') &&
               (lora_rx_buffer[3] == 'R') &&
               (lora_rx_buffer[4] == 'I');
    }

    for(u16 i = 0U; i < lora_rx_len; i++)
    {
        if(lora_rx_buffer[i] != (u8)prefix[i])
            return 0;
    }
    return 1;
}

static u8 LoRa_Rx_Has_Protocol_Tail(void)
{
    if(lora_rx_len < 3U) return 0;

    for(u16 i = 2U; i < lora_rx_len; i++)
    {
        if((lora_rx_buffer[i - 2U] == '*') &&
           (lora_rx_buffer[i - 1U] == '0') &&
           (lora_rx_buffer[i] == '0'))
        {
            return 1;
        }
    }
    return 0;
}

void LoRa_Rx_Timeout_Check(void)
{
    if(lora_rx_complete || lora_rx_overflow)
        return;

    if(lora_last_rx_time == 0)
        return;

    if((u32)(GetTick() - lora_last_rx_time) >= LORA_RX_TIMEOUT_MS)
    {
        NVIC_DisableIRQ(USART2_IRQn);
        if(lora_rx_len > 0)
        {
            if(LoRa_Rx_Is_Agri_Prefix() && !LoRa_Rx_Has_Protocol_Tail())
            {
                lora_last_rx_time = GetTick();
                NVIC_EnableIRQ(USART2_IRQn);
                return;
            }

            lora_rx_complete = 1;
        }
        lora_last_rx_time = 0;
        NVIC_EnableIRQ(USART2_IRQn);
    }
}
