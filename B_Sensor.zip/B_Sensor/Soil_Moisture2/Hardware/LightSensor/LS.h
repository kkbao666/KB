#ifndef HARDWARE_LIGHTSENSOR_LS_H_
#define HARDWARE_LIGHTSENSOR_LS_H_

#include "../../Debug/debug.h"
#include "../System/system.h"

#define LIGHT_DARK_VALUE    3000
#define LIGHT_BRIGHT_VALUE  200

void Light_ADC_Init(void);
u16  Light_Get_ADC_Raw(void);

u16  Light_Get_Filtered_ADC(void);
u8   Light_Get_Percent(void);

void Light_Start_Avg_Sample(void);
void Light_Task(void);
u8   Light_Is_Avg_Done(void);
u16  Light_Get_Avg_Result(void);

void Light_Start_Get_Percent(void);
u8   Light_Get_Percent_Result(void);

#endif
