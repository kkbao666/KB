#include "LS.h"

static u8   light_sample_count = 0;
static u32  light_sample_sum = 0;
static u32  light_last_sample_time = 0;
static u16  light_avg_result = 0;
static u8   light_avg_done = 0;
static u8   light_busy = 0;

void Light_ADC_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_PB2PeriphClockCmd(RCC_PB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

u16 Light_Get_ADC_Raw(void)
{
    u16 val;
    u32 timeout = 100000;

    ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 1, ADC_SampleTime_CyclesMode0);
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);

    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC))
    {
        if(--timeout == 0) return 0;
    }

    val = ADC_GetConversionValue(ADC1);
    return val;
}

void Light_Start_Avg_Sample(void)
{
    if(light_busy) return;

    light_sample_count = 0;
    light_sample_sum = 0;
    light_avg_done = 0;
    light_busy = 1;
    light_last_sample_time = GetTick();
}

void Light_Task(void)
{
    u16 raw;

    if(!light_busy || light_avg_done) return;

    if(GetTick() - light_last_sample_time < 1000) return;

    RCC_PB2PeriphClockCmd(RCC_PB2Periph_ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    raw = Light_Get_ADC_Raw();
    light_sample_sum += raw;
    light_sample_count++;
    light_last_sample_time = GetTick();

    ADC_Cmd(ADC1, DISABLE);
    RCC_PB2PeriphClockCmd(RCC_PB2Periph_ADC1, DISABLE);

    if(light_sample_count >= 10)
    {
        light_avg_result = (u16)(light_sample_sum / 10);
        light_avg_done = 1;
        light_busy = 0;
    }
}

u8 Light_Is_Avg_Done(void)
{
    return light_avg_done;
}

u16 Light_Get_Avg_Result(void)
{
    return light_avg_result;
}

u16 Light_Get_Filtered_ADC(void)
{
    Light_Start_Avg_Sample();
    while(!light_avg_done)
    {
        Light_Task();
    }
    return light_avg_result;
}

u8 Light_Get_Percent(void)
{
    u16 adc_val = Light_Get_Filtered_ADC();
    u16 range = LIGHT_DARK_VALUE - LIGHT_BRIGHT_VALUE;

    if(range == 0) return 0;
    if(adc_val >= LIGHT_DARK_VALUE) return 0;
    if(adc_val <= LIGHT_BRIGHT_VALUE) return 100;
    return (u8)((LIGHT_DARK_VALUE - adc_val) * 100 / range);
}

void Light_Start_Get_Percent(void)
{
    Light_Start_Avg_Sample();
}

u8 Light_Get_Percent_Result(void)
{
    u16 adc_val = light_avg_result;
    u16 range = LIGHT_DARK_VALUE - LIGHT_BRIGHT_VALUE;

    if(range == 0) return 0;
    if(adc_val >= LIGHT_DARK_VALUE) return 0;
    if(adc_val <= LIGHT_BRIGHT_VALUE) return 100;
    return (u8)((LIGHT_DARK_VALUE - adc_val) * 100 / range);
}
