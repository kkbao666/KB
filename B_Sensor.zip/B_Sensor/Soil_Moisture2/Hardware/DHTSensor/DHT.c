#include "DHT.h"
#include "system.h"

#define DHT_PORT    GPIOB

static u16 dht_pin = GPIO_Pin_3;

#define DHT_WAIT_LOOP_MAX   60000UL

static void DHT_SetOutput(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    RCC_PB2PeriphClockCmd(RCC_PB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = dht_pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DHT_PORT, &GPIO_InitStructure);
}

static void DHT_SetInput(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    RCC_PB2PeriphClockCmd(RCC_PB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = dht_pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DHT_PORT, &GPIO_InitStructure);
}

static void DHT_ReleaseBus(void)
{
    DHT_SetInput();
}

static void DHT_SetLow(void)
{
    GPIO_ResetBits(DHT_PORT, dht_pin);
}

static uint8_t DHT_ReadPin(void)
{
    return GPIO_ReadInputDataBit(DHT_PORT, dht_pin);
}

static void DHT_DelayUs(uint32_t us)
{
    uint32_t count = us * 24U;
    while(count--) __NOP();
}

static void DHT_DelayMs(uint32_t ms)
{
    uint32_t start = GetTick();
    uint32_t target = ms * 96000U;
    while(GetTickDiff(GetTick(), start) < target);
}

static uint8_t DHT_WaitLevelLoop(uint8_t level, uint32_t timeout_loop)
{
    while(DHT_ReadPin() != level)
    {
        if(timeout_loop-- == 0UL) return 1U;
    }
    return 0U;
}

static uint32_t DHT_MeasureLevelLoop(uint8_t level, uint32_t timeout_loop, uint8_t *is_timeout)
{
    uint32_t count = 0UL;

    if(is_timeout != NULL) *is_timeout = 0U;

    while(DHT_ReadPin() == level)
    {
        count++;
        if(count >= timeout_loop)
        {
            if(is_timeout != NULL) *is_timeout = 1U;
            break;
        }
    }

    return count;
}

void DHT_SetPin(u16 gpio_pin)
{
    dht_pin = gpio_pin;
}

void DHT_Init(u16 gpio_pin)
{
    DHT_SetPin(gpio_pin);
    DHT_ReleaseBus();

    DHT_DelayMs(2500);

    printf("[DHT] init ok, TYPE=AM2302/DHT22, DATA pin mask=0x%04X, idle=%u\r\n",
           (unsigned int)dht_pin,
           (unsigned int)DHT_ReadPin());
}

u8 DHT_Read(DHT_InfoTypeDef *dht_info)
{
    uint8_t data[5] = {0};
    uint8_t i, j;
    uint8_t timeout_flag = 0U;
    uint32_t response_high_count = 0UL;
    uint32_t bit_threshold = 0UL;

    if(dht_info == NULL) return 1U;

    dht_info->temperature = 0.0f;
    dht_info->humidity = 0.0f;
    dht_info->type = DHT_UNKNOWN;
    dht_info->last_error = 1U;

    DHT_ReleaseBus();
    DHT_DelayUs(30);
    if(DHT_ReadPin() == 0U)
    {
        printf("[DHT] WARN: DATA is LOW before start, check wiring/pull-up\r\n");
    }

    DHT_SetOutput();
    DHT_SetLow();
    DHT_DelayMs(2);

    DHT_ReleaseBus();
    DHT_DelayUs(30);

    __disable_irq();

    if(DHT_WaitLevelLoop(0U, DHT_WAIT_LOOP_MAX))
    {
        __enable_irq();
        DHT_ReleaseBus();
        printf("[DHT] No response. Check DATA pin, VCC/GND, and pull-up\r\n");
        return 1U;
    }

    if(DHT_WaitLevelLoop(1U, DHT_WAIT_LOOP_MAX))
    {
        __enable_irq();
        DHT_ReleaseBus();
        printf("[DHT] Response low timeout\r\n");
        return 1U;
    }

    response_high_count = DHT_MeasureLevelLoop(1U, DHT_WAIT_LOOP_MAX, &timeout_flag);
    if(timeout_flag || response_high_count < 10UL)
    {
        __enable_irq();
        DHT_ReleaseBus();
        printf("[DHT] Response high timeout/count abnormal: %lu\r\n", response_high_count);
        return 1U;
    }

    bit_threshold = response_high_count / 2UL;
    if(bit_threshold < 10UL) bit_threshold = 10UL;

    for(i = 0U; i < 5U; i++)
    {
        for(j = 0U; j < 8U; j++)
        {
            uint32_t k;
            uint8_t bit_is_1;

            if(DHT_WaitLevelLoop(1U, DHT_WAIT_LOOP_MAX))
            {
                __enable_irq();
                DHT_ReleaseBus();
                printf("[DHT] Bit %u.%u rise timeout\r\n", i, j);
                return 1U;
            }

            bit_is_1 = 1U;
            for(k = 0UL; k < bit_threshold; k++)
            {
                if(DHT_ReadPin() == 0U)
                {
                    bit_is_1 = 0U;
                    break;
                }
            }

            data[i] <<= 1;
            if(bit_is_1)
            {
                data[i] |= 1U;

                if(!((i == 4U) && (j == 7U)))
                {
                    if(DHT_WaitLevelLoop(0U, DHT_WAIT_LOOP_MAX))
                    {
                        __enable_irq();
                        DHT_ReleaseBus();
                        printf("[DHT] Bit %u.%u high end timeout\r\n", i, j);
                        return 1U;
                    }
                }
            }
        }
    }

    __enable_irq();
    DHT_ReleaseBus();

    printf("[DHT] resp_high=%lu, threshold=%lu\r\n", response_high_count, bit_threshold);
    printf("[DHT] Raw: %02X %02X %02X %02X %02X\r\n",
           data[0], data[1], data[2], data[3], data[4]);

    if((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4])
    {
        printf("[DHT] Checksum fail\r\n");
        return 1U;
    }

    {
        uint16_t hum_raw = ((uint16_t)data[0] << 8) | data[1];
        uint16_t temp_raw = ((uint16_t)data[2] << 8) | data[3];

        dht_info->humidity = (float)hum_raw / 10.0f;
        if(temp_raw & 0x8000U)
        {
            temp_raw &= 0x7FFFU;
            dht_info->temperature = -(float)temp_raw / 10.0f;
        }
        else
        {
            dht_info->temperature = (float)temp_raw / 10.0f;
        }
        dht_info->type = DHT22;
    }

    if((dht_info->humidity < 0.0f) || (dht_info->humidity > 100.0f) ||
       (dht_info->temperature < -40.0f) || (dht_info->temperature > 80.0f))
    {
        printf("[DHT] Range fail: TEMP=%.1f,HUM=%.1f\r\n",
               dht_info->temperature, dht_info->humidity);
        return 1U;
    }

    dht_info->last_error = 0U;

    printf("[DHT] OK: TYPE=AM2302/DHT22,TEMP=%d,HUM=%d\r\n",
           (int)(dht_info->temperature + 0.5f),
           (int)(dht_info->humidity + 0.5f));

    return 0U;
}

void DHT_PrintInfo(DHT_InfoTypeDef *dht_info)
{
    if(dht_info == NULL) return;
    if(dht_info->last_error != 0U)
    {
        printf("DHT Read Failed!\r\n");
        return;
    }
    printf("Temperature: %.1f C\r\n", dht_info->temperature);
    printf("Humidity: %.1f %%\r\n", dht_info->humidity);
}
