#ifndef HARDWARE_DHTSENSOR_DHT_H_
#define HARDWARE_DHTSENSOR_DHT_H_

#include "ch32l103.h"
#include "system.h"
#include <stdio.h>

typedef enum
{
    DHT11,
    DHT22,
    DHT_UNKNOWN
} DHT_TypeDef;

typedef struct
{
    float temperature;
    float humidity;
    DHT_TypeDef type;
    u8 last_error;
} DHT_InfoTypeDef;

void DHT_Init(u16 gpio_pin);
void DHT_SetPin(u16 gpio_pin);
u8 DHT_Read(DHT_InfoTypeDef *dht_info);
void DHT_PrintInfo(DHT_InfoTypeDef *dht_info);

#endif
