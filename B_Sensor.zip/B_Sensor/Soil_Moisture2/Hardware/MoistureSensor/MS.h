#ifndef HARDWARE_MOISTURESENSOR_MS_H_
#define HARDWARE_MOISTURESENSOR_MS_H_

#include "../../Debug/debug.h"
#include "../System/system.h"

#define SOIL_DRY_VALUE   3400
#define SOIL_WET_VALUE   1350

void Soil_ADC_Init(void);
u16  Soil_Get_ADC_Raw(void);
u16  Soil_Get_ConversionVal(s16 val);

u16  Soil_Get_Filtered_ADC(void);
u8   Soil_Get_Humidity(void);

void Soil_Start_Avg_Sample(void);
void Soil_Task(void);
u8   Soil_Is_Avg_Done(void);
u16  Soil_Get_Avg_Result(void);

void Soil_Start_Get_Humidity(void);
u8   Soil_Get_Humidity_Result(void);

extern s16 Calibrattion_Val;

#endif
