#include "MS.h"

s16 Calibrattion_Val = 0;

static u8   soil_sample_count = 0;
static u32  soil_sample_sum = 0;
static u32  soil_last_sample_time = 0;
static u16  soil_avg_result = 0;
static u8   soil_avg_done = 0;
static u8   soil_busy = 0;

void Soil_ADC_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    ADC_InitTypeDef  ADC_InitStructure = {0};

    RCC_PB2PeriphClockCmd(RCC_PB2Periph_GPIOA | RCC_PB2Periph_ADC1, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    ADC_DeInit(ADC1);

    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);

    ADC_Cmd(ADC1, ENABLE);
    Simple_Delay(1);

    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));

    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));

    Calibrattion_Val = Get_CalibrationValue(ADC1);

    ADC_Cmd(ADC1, ENABLE);
}

u16 Soil_Get_ADC_Raw(void)
{
    u16 val;
    u32 timeout = 100000;

    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_CyclesMode0);
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);

    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC))
    {
        if(--timeout == 0) return 0;
    }

    val = ADC_GetConversionValue(ADC1);
    return val;
}

u16 Soil_Get_ConversionVal(s16 val)
{
    s32 result = (s32)val + Calibrattion_Val;
    if(result < 0) return 0;
    if(result > 4095) return 4095;
    return (u16)result;
}

void Soil_Start_Avg_Sample(void)
{
    if(soil_busy) return;

    soil_sample_count = 0;
    soil_sample_sum = 0;
    soil_avg_done = 0;
    soil_busy = 1;
    soil_last_sample_time = GetTick();
}

void Soil_Task(void)
{
    u16 raw;

    if(!soil_busy || soil_avg_done) return;

    if(GetTick() - soil_last_sample_time < 1000) return;

    RCC_PB2PeriphClockCmd(RCC_PB2Periph_ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    raw = Soil_Get_ADC_Raw();
    soil_sample_sum += Soil_Get_ConversionVal(raw);
    soil_sample_count++;

    soil_last_sample_time = GetTick();

    ADC_Cmd(ADC1, DISABLE);
    RCC_PB2PeriphClockCmd(RCC_PB2Periph_ADC1, DISABLE);

    if(soil_sample_count >= 10)
    {
        soil_avg_result = (u16)(soil_sample_sum / 10);
        soil_avg_done = 1;
        soil_busy = 0;
    }
}

u8 Soil_Is_Avg_Done(void)
{
    return soil_avg_done;
}

u16 Soil_Get_Avg_Result(void)
{
    return soil_avg_result;
}

u16 Soil_Get_Filtered_ADC(void)
{
    Soil_Start_Avg_Sample();
    while(!soil_avg_done)
    {
        Soil_Task();
    }
    return soil_avg_result;
}

u8 Soil_Get_Humidity(void)
{
    u16 adc_val = Soil_Get_Filtered_ADC();
    u16 range = SOIL_DRY_VALUE - SOIL_WET_VALUE;

    if(range == 0) return 0;
    if(adc_val >= SOIL_DRY_VALUE) return 0;
    if(adc_val <= SOIL_WET_VALUE) return 100;

    return (u8)((SOIL_DRY_VALUE - adc_val) * 100 / range);
}

void Soil_Start_Get_Humidity(void)
{
    Soil_Start_Avg_Sample();
}

u8 Soil_Get_Humidity_Result(void)
{
    u16 adc_val = soil_avg_result;
    u16 range = SOIL_DRY_VALUE - SOIL_WET_VALUE;

    if(range == 0) return 0;
    if(adc_val >= SOIL_DRY_VALUE) return 0;
    if(adc_val <= SOIL_WET_VALUE) return 100;

    return (u8)((SOIL_DRY_VALUE - adc_val) * 100 / range);
}
