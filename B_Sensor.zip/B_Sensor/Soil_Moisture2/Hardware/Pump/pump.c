#include "pump.h"

void Pump_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_PB2PeriphClockCmd(RCC_PB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    Pump_Off();
}

void Pump_On(void)
{
    GPIO_SetBits(GPIOA, GPIO_Pin_0);
}

void Pump_Off(void)
{
    GPIO_ResetBits(GPIOA, GPIO_Pin_0);
}
