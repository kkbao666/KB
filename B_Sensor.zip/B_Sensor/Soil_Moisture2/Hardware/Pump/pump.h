#ifndef __PUMP_H
#define __PUMP_H

#include "../../Debug/debug.h"

void Pump_Init(void);
void Pump_On(void);
void Pump_Off(void);

#endif
