#include "rtc.h"

static volatile u8 rtc_wakeup_flag = 0;

void RTC_Init(u8 clock_source)
{
    RCC_PB1PeriphClockCmd(RCC_PB1Periph_PWR | RCC_PB1Periph_BKP, ENABLE);

    PWR_BackupAccessCmd(ENABLE);

    BKP_DeInit();

    if(clock_source == RTC_CLOCK_LSE)
    {
        RCC_LSEConfig(RCC_LSE_ON);
        while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);

        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
    }
    else
    {
        RCC_LSICmd(ENABLE);
        while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);

        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);
    }

    RCC_RTCCLKCmd(ENABLE);

    RTC_WaitForSynchro();

    RTC_WaitForLastTask();
    RTC_EnterConfigMode();

    if(clock_source == RTC_CLOCK_LSE)
    {
        RTC_SetPrescaler(32767);
    }
    else
    {
        RTC_SetPrescaler(39999);
    }

    RTC_ExitConfigMode();
    RTC_WaitForLastTask();

    RTC_ClearFlag(RTC_FLAG_ALR);
}

void RTC_SetWakeUpSeconds(u32 seconds)
{
    u32 current = RTC_GetCounter();
    u32 alarm = current + seconds;
    RTC_SetAlarm(alarm);
}

u8 RTC_IsWakeUp(void)
{
    if(RTC_GetFlagStatus(RTC_FLAG_ALR) != RESET)
    {
        RTC_ClearFlag(RTC_FLAG_ALR);
        return 1;
    }
    return 0;
}

u8 RTC_GetWakeUpFlag(void)
{
    u8 ret = rtc_wakeup_flag;
    if(ret)
    {
        rtc_wakeup_flag = 0;
    }
    return ret;
}

void RTC_WakeUp_IRQHandler(void)
{
    if(RTC_GetFlagStatus(RTC_FLAG_ALR) != RESET)
    {
        RTC_ClearFlag(RTC_FLAG_ALR);
        rtc_wakeup_flag = 1;
        EXTI_ClearITPendingBit(EXTI_Line17);
    }
}
