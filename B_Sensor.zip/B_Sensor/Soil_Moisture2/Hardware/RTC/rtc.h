#ifndef HARDWARE_RTC_RTC_H_
#define HARDWARE_RTC_RTC_H_

#include "../../Peripheral/inc/ch32l103.h"
#include "../System/system.h"

#define RTC_CLOCK_LSE         0
#define RTC_CLOCK_LSI         1

void RTC_Init(u8 clock_source);
void RTC_SetWakeUpSeconds(u32 seconds);
u8   RTC_IsWakeUp(void);
u8   RTC_GetWakeUpFlag(void);
void RTC_WakeUp_IRQHandler(void);

#endif
