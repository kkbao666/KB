#include "ch32l103.h"
#include "../Hardware/System/system.h"
#include "../Hardware/Lora/lora.h"
#include "../Hardware/MoistureSensor/MS.h"
#include "../Hardware/LightSensor/LS.h"
#include "../Hardware/Pump/pump.h"
#include "../Hardware/DHTSensor/DHT.h"
#include <stdio.h>
#include <string.h>

#define TICK_1S                     96000000U
#define AGRI_SENSOR_PERIOD_TICKS    (TICK_1S * 5)

#define AGRI_DEFAULT_AIR_HUMIDITY    60U
#define AGRI_DEFAULT_AIR_TEMP        25U
#define AGRI_ADC_REF_MV              3300U
#define AGRI_ADC_FULL_SCALE          4095U
#define AGRI_LUX_FULL_SCALE          1000U
#define AGRI_DHT_PIN                 GPIO_Pin_3

#define STK_CTLR    (*(volatile uint32_t *)0xE000F000)
#define STK_CNT     (*(volatile uint32_t *)0xE000F008)
#define STK_CMP     (*(volatile uint32_t *)0xE000F010)

static u16 send_seq = 1;

static u8 soil_humidity = 0;
static u16 soil_adc = 0;
static u16 soil_volt_mv = 0;
static u16 light_adc = 0;
static u16 light_lux = 0;
static u8 air_humidity = AGRI_DEFAULT_AIR_HUMIDITY;
static u8 air_temperature = AGRI_DEFAULT_AIR_TEMP;

static u8 pump_is_on = 0;
static u32 watering_start_ms = 0;
static u32 watering_target_s = 0;

extern volatile u32 usart2_rx_count;

static u16 Agri_Next_Seq(void)
{
    u16 seq = send_seq++;
    if(send_seq > 9999U) send_seq = 1U;
    return seq;
}

static u16 Agri_Get_Seq(const char *line)
{
    const char *p = line;
    u16 seq = 0;

    for(u8 i = 0; i < 3U; i++)
    {
        p = strchr(p, ',');
        if(p == 0) return 0;
        p++;
    }

    while((*p >= '0') && (*p <= '9'))
    {
        seq = (u16)(seq * 10U + (u16)(*p - '0'));
        p++;
    }

    return seq;
}

static u8 Agri_Get_U32_Field(const char *line, const char *key, u32 *value)
{
    const char *p = line;
    u32 key_len = (u32)strlen(key);

    while((p = strstr(p, key)) != 0)
    {
        u32 result = 0;
        u8 found_digit = 0;

        if((p != line) && (*(p - 1) != ',') && (*(p - 1) != ' '))
        {
            p += key_len;
            continue;
        }

        p += key_len;
        if(*p != '=')
        {
            continue;
        }
        p++;

        while((*p >= '0') && (*p <= '9'))
        {
            result = result * 10U + (u32)(*p - '0');
            found_digit = 1;
            p++;
        }

        if(found_digit)
        {
            *value = result;
            return 1;
        }
    }

    return 0;
}

static u8 Agri_Has_Stop_Request(const char *line)
{
    return (strstr(line, "STOP=1") != 0) ? 1U : 0U;
}

static u8 Agri_Soil_Percent_From_Adc(u16 adc)
{
    u16 range = SOIL_DRY_VALUE - SOIL_WET_VALUE;

    if(range == 0U) return 0;
    if(adc >= SOIL_DRY_VALUE) return 0;
    if(adc <= SOIL_WET_VALUE) return 100;

    return (u8)(((u32)(SOIL_DRY_VALUE - adc) * 100U) / range);
}

static u16 Agri_Millivolt_From_Adc(u16 adc)
{
    return (u16)(((u32)adc * AGRI_ADC_REF_MV + (AGRI_ADC_FULL_SCALE / 2U)) /
                 AGRI_ADC_FULL_SCALE);
}

static u16 Agri_Lux_From_Adc(u16 adc)
{
    if(adc > AGRI_ADC_FULL_SCALE)
    {
        adc = AGRI_ADC_FULL_SCALE;
    }

    return (u16)((((u32)(AGRI_ADC_FULL_SCALE - adc)) * AGRI_LUX_FULL_SCALE +
                  (AGRI_ADC_FULL_SCALE / 2U)) / AGRI_ADC_FULL_SCALE);
}

static void Agri_Read_Sensors(void)
{
    soil_adc = Soil_Get_ConversionVal((s16)Soil_Get_ADC_Raw());
    soil_humidity = Agri_Soil_Percent_From_Adc(soil_adc);
    soil_volt_mv = Agri_Millivolt_From_Adc(soil_adc);

    light_adc = Light_Get_ADC_Raw();
    light_lux = Agri_Lux_From_Adc(light_adc);

    {
        DHT_InfoTypeDef dht;
        if(DHT_Read(&dht) == 0U)
        {
            if(dht.humidity < 0.0f) dht.humidity = 0.0f;
            if(dht.humidity > 100.0f) dht.humidity = 100.0f;
            if(dht.temperature < 0.0f) dht.temperature = 0.0f;
            if(dht.temperature > 99.0f) dht.temperature = 99.0f;

            air_humidity = (u8)(dht.humidity + 0.5f);
            air_temperature = (u8)(dht.temperature + 0.5f);
        }
        else
        {
            printf("[A][DHT] read failed, keep HUM=%u,TEMP=%u\r\n",
                   (unsigned int)air_humidity,
                   (unsigned int)air_temperature);
        }
    }
}

static void Agri_Send_Sensors_To_B(void)
{
    char msg[128];

    snprintf(msg, sizeof(msg),
            "$AGRI,A,B,%04u,SENS,SOIL=%u,LUX=%u,HUM=%u,TEMP=%u*00\r\n",
            Agri_Next_Seq(),
            (unsigned int)soil_humidity,
            (unsigned int)light_lux,
            (unsigned int)air_humidity,
            (unsigned int)air_temperature);

    LoRa_Send_String(msg);
    printf("[A][TX] %s", msg);
}

static void Agri_Send_Cmd_Ack(u16 seq, const char *state)
{
    char msg[80];

    snprintf(msg, sizeof(msg),
            "$AGRI,A,B,%04u,ACK,TYPE=CMD,STATE=%s*00\r\n", seq, state);

    LoRa_Send_String(msg);
    printf("[A][TX] %s", msg);
}

static void Agri_Send_Exec_Report(const char *state, u32 run_s, u32 dur_s)
{
    char msg[96];

    snprintf(msg, sizeof(msg),
            "$AGRI,A,B,%04u,EXEC,RUN=%lu,DUR=%lu,STATE=%s*00\r\n",
            Agri_Next_Seq(),
            (unsigned long)run_s,
            (unsigned long)dur_s,
            state);

    LoRa_Send_String(msg);
    printf("[A][TX] %s", msg);
}

static u32 Agri_Current_Duration_S(void)
{
    if(!pump_is_on) return 0;
    return (u32)((GetTickDiff(GetTick(), watering_start_ms) + (TICK_1S / 2U)) / TICK_1S);
}

static void Agri_Start_Pump(u32 run_s)
{
    if(pump_is_on)
    {
        printf("[A] WARN: pump already running, ignore duplicate START\r\n");
        return;
    }

    watering_target_s = run_s;
    watering_start_ms = GetTick();
    Pump_On();
    pump_is_on = 1;

    printf("[A] pump start, target=%lu s\r\n", (unsigned long)run_s);
}

static void Agri_Stop_Pump_And_Report(void)
{
    if(!pump_is_on)
    {
        printf("[A] WARN: pump already stopped, ignore duplicate STOP\r\n");
        return;
    }

    u32 dur_s = Agri_Current_Duration_S();
    u32 target_s = watering_target_s;

    Pump_Off();
    pump_is_on = 0;
    watering_target_s = 0;

    printf("[A] pump stop by B, dur=%lu s\r\n", (unsigned long)dur_s);
    Agri_Send_Exec_Report("STOP", target_s, dur_s);
}

static void Agri_Handle_Line_From_B(char *line)
{
    u16 rx_seq;
    u32 run_s = 0;
    u8 has_run;
    u8 stop_request;

    if(strstr(line, "$AGRI,B,A,") == 0)
    {
        return;
    }

    printf("[A][RX] %s\r\n", line);
    rx_seq = Agri_Get_Seq(line);

    if(strstr(line, ",ACK,") != 0) return;
    if(strstr(line, ",ERR,") != 0) return;
    if(strstr(line, ",CMD,") == 0) return;

    has_run = Agri_Get_U32_Field(line, "RUN", &run_s);
    stop_request = Agri_Has_Stop_Request(line);

    if(stop_request || (has_run && (run_s == 0U)))
    {
        Agri_Send_Cmd_Ack(rx_seq, "STOP");
        Agri_Stop_Pump_And_Report();
        return;
    }

    if(has_run && (run_s > 0U))
    {
        Agri_Start_Pump(run_s);
        Agri_Send_Cmd_Ack(rx_seq, "EXEC");
        Agri_Send_Exec_Report("EXEC", run_s, 0);
        return;
    }

    printf("[A] WARN: unrecognized CMD: %s\r\n", line);
    Agri_Send_Cmd_Ack(rx_seq, "ERROR");
}

static void Agri_Process_Lora_Rx(void)
{
    u8 buf[LORA_RX_BUF_SIZE + 1U];
    u16 len;

    if(!lora_rx_complete) return;

    len = LoRa_Read_Buffer(buf, LORA_RX_BUF_SIZE);

    while((len > 0U) && ((buf[len - 1U] == '\r') || (buf[len - 1U] == '\n')))
    {
        len--;
    }
    buf[len] = '\0';

    if(len == 0U) return;

    printf("[A][RAW] len=%d, str: %s\r\n", len, buf);
    Agri_Handle_Line_From_B((char *)buf);
}

int main(void)
{
    u32 last_sensor_ms = 0;

    SystemInit();

    USART1_Printf_Init();

    printf("\r\n=== AGRI A NODE ===\r\n");

    STK_CMP = 96000;
    STK_CNT = 0;
    STK_CTLR = 0b111;

    NVIC_SetPriority(SysTicK_IRQn, 2);
    __enable_irq();

    printf("[SYS] CTLR=%08lX CMP=%08lX\r\n", STK_CTLR, STK_CMP);

    LoRa_Init();
    Pump_Init();
    Soil_ADC_Init();
    Light_ADC_Init();
    DHT_Init(AGRI_DHT_PIN);

    Agri_Read_Sensors();
    Agri_Send_Sensors_To_B();
    last_sensor_ms = GetTick();

    printf("[A] LoRa ready, waiting for B commands...\r\n");

    while(1)
    {
        static u32 last_tick_print = 0;
        u32 now = GetTick();

        LoRa_Rx_Timeout_Check();
        Agri_Process_Lora_Rx();

        if(GetTickDiff(now, last_tick_print) >= TICK_1S)
        {
            printf("[TICK] %lu, RX_count=%lu\r\n", now, usart2_rx_count);
            last_tick_print = now;
        }

        if(GetTickDiff(now, last_sensor_ms) >= AGRI_SENSOR_PERIOD_TICKS)
        {
            Agri_Read_Sensors();
            Agri_Send_Sensors_To_B();
            last_sensor_ms = now;
        }
    }
}
