#include "ch32l103.h"
#include "../Hardware/Lora/lora.h"
#include "../Hardware/RTC/rtc.h"
#include "system.h"
#include <stdio.h>

extern volatile u8 lora_rx_buffer[256];
extern volatile u16 lora_rx_len;
extern volatile u8 lora_rx_complete;
extern volatile u8 lora_rx_overflow;
extern volatile u32 lora_last_rx_time;
extern volatile u32 systick_ms;

volatile u32 usart2_rx_count = 0;

void USART2_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART2_IRQHandler(void)
{
    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        u8 data = (u8)USART_ReceiveData(USART2);

        usart2_rx_count++;

        if(data == '\r')
        {
            USART_ClearITPendingBit(USART2, USART_IT_RXNE);
            return;
        }

        LoRa_Update_Rx_Time();

        if(lora_rx_complete)
        {
            USART_ClearITPendingBit(USART2, USART_IT_RXNE);
            return;
        }

        if(data == '\n')
        {
            if(lora_rx_len > 0)
            {
                lora_rx_complete = 1;
            }
        }
        else if(lora_rx_len < LORA_RX_BUF_SIZE)
        {
            lora_rx_buffer[lora_rx_len++] = data;

            if((lora_rx_len >= 3U) &&
               (lora_rx_buffer[lora_rx_len - 3U] == '*') &&
               (lora_rx_buffer[lora_rx_len - 2U] == '0') &&
               (lora_rx_buffer[lora_rx_len - 1U] == '0'))
            {
                lora_rx_complete = 1;
            }
            else if((data == 'n') && (lora_rx_len >= 2U) &&
                    (lora_rx_buffer[lora_rx_len - 2U] == '\\'))
            {
                lora_rx_len--;
                lora_rx_buffer[lora_rx_len] = 0;
                lora_rx_complete = 1;
            }
        }
        else
        {
            lora_rx_overflow = 1;
            lora_rx_complete = 1;
        }

        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
}

void RTC_IRQHandler(void) __attribute__((interrupt));
void RTC_IRQHandler(void)
{
    RTC_WakeUp_IRQHandler();
}
