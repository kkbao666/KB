/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2022/01/18
 * Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/
/*
 *@Note
Web Server example, this program is used to demonstrate the function
of configuring the WCHNET chip through a web browser, the WCHNET chip has a built-in web server,
The web page can implement WCHNET's network parameter configuration and password management.
For details on the selection of engineering chips,
please refer to the "CH32V30x Evaluation Board Manual" under the CH32V307EVT\EVT\PUB folder.
 */
#include "string.h"
#include "stdio.h"
#include "stdlib.h"      //  ?��?? atoi()
#include "eth_driver.h"
#include "HTTPS.h"

#define B_UART_RX_BUF_SIZE 512
#define AGRI_MAX_RUN_S     300

u8 MACAddr[6];                                                  //MAC address
u8 IPAddr[4];                                                   //IP address
u8 GWIPAddr[4];                                                 //Gateway IP address
u8 IPMask[4];                                                   //subnet mask

u8 SocketId, SocketIdForListen;
u8 RecvBuffer[RECE_BUF_LEN], HTTPDataBuffer[RECE_BUF_LEN];
u8 SocketRecvBuf[WCHNET_MAX_SOCKET_NUM][RECE_BUF_LEN];          //socket receive buffer
u16 DESPORT, SRCPORT;                                           //port

static u8 B_UART_RxBuffer[B_UART_RX_BUF_SIZE];
static u16 B_UART_RxLen = 0;
static u16 AgriSeq = 1;

static void B_UART_SendText(const char *text)
{
    while(*text)
    {
        USART_SendData(USART3, (u8)*text++);
        while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
    }

    while(USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
}

static u16 AGRI_GetSeq(const char *line)
{
    const char *p = line;
    u16 seq = 0;
    u8 i;

    for(i = 0; i < 3; i++)
    {
        p = strchr(p, ',');
        if(p == NULL) return 0;
        p++;
    }

    while((*p >= '0') && (*p <= '9'))
    {
        seq = (u16)(seq * 10 + (u16)(*p - '0'));
        p++;
    }

    return seq;
}

static u16 AGRI_NextSeq(void)
{
    u16 seq = AgriSeq++;
    if(AgriSeq > 9999) AgriSeq = 1;
    return seq;
}

static u8 AGRI_GetU32Field(const char *line, const char *key, u32 *value)
{
    const char *p = line;
    u32 key_len = (u32)strlen(key);

    while((p = strstr(p, key)) != NULL)
    {
        u32 result = 0;
        u8 found = 0;

        if((p != line) && (*(p - 1) != ',') && (*(p - 1) != ' '))
        {
            p += key_len;
            continue;
        }

        p += key_len;
        if(*p != '=')
        {
            continue;
        }
        p++;

        while((*p >= '0') && (*p <= '9'))
        {
            result = result * 10 + (u32)(*p - '0');
            found = 1;
            p++;
        }

        if(found)
        {
            *value = result;
            return 1;
        }
    }

    return 0;
}

static u8 AGRI_GetStringField(const char *line, const char *key, char *value, u8 size)
{
    const char *p = line;
    u32 key_len = (u32)strlen(key);
    u8 i = 0;

    if(size == 0) return 0;

    while((p = strstr(p, key)) != NULL)
    {
        if((p != line) && (*(p - 1) != ',') && (*(p - 1) != ' '))
        {
            p += key_len;
            continue;
        }

        p += key_len;
        if(*p != '=')
        {
            continue;
        }
        p++;

        while((*p != '\0') && (*p != ',') && (*p != '*') && (i < size - 1))
        {
            value[i++] = *p++;
        }

        value[i] = '\0';
        return (i > 0);
    }

    value[0] = '\0';
    return 0;
}
//  main.c ??? #include ��
extern int current_humidity;
extern int current_light;
extern int current_air_humidity;
extern int current_temperature;
extern int current_flow;
extern int pump_status;

// ???
extern int current_countdown;

static void AGRI_C_HandleLine(char *line)
{
    u16 seq;
    u32 value;
    u32 run_value = 0;
    u32 remain_value = 0;
    u8 has_run;
    u8 has_remain;
    char temp_str[16];
    char state_str[16] = "";

    if(strstr(line, "$AGRI,B,C,") == NULL)
        return;

    printf("B UART RX: %s", line);
    seq = AGRI_GetSeq(line);

    if(strstr(line, ",RPT,") != NULL)
    {
        /* Do not ACK every B report. C only displays RPT; replying each time
           creates unnecessary C->B UART traffic and can delay manual commands. */

        if(AGRI_GetU32Field(line, "SOIL", &value))
        {
            if(value <= 100) current_humidity = (int)value;
        }

        if(AGRI_GetU32Field(line, "LUX", &value) ||
           AGRI_GetU32Field(line, "ULX", &value))
        {
            if(value <= 100000) current_light = (int)value;
        }

        if(AGRI_GetU32Field(line, "HUM", &value) ||
           AGRI_GetU32Field(line, "HUMI", &value))
        {
            if(value <= 100) current_air_humidity = (int)value;
        }

        if(AGRI_GetU32Field(line, "TEMP", &value))
        {
            if(value <= 85) current_temperature = (int)value;
        }

        if(AGRI_GetStringField(line, "PLANT", temp_str, sizeof(temp_str)))
        {
            printf("plant: %s\r\n", temp_str);
        }

        (void)AGRI_GetStringField(line, "STATE", state_str, sizeof(state_str));
        pump_status = (strcmp(state_str, "EXEC") == 0) ? 1 : 0;
        printf("pump_status: %d\r\n", pump_status);

        has_run = AGRI_GetU32Field(line, "RUN", &run_value);
        has_remain = AGRI_GetU32Field(line, "REMAIN", &remain_value);

        if(strcmp(state_str, "EXEC") == 0)
        {
            /* countdown shown by C webpage must come from B REMAIN only */
            if(has_remain) current_countdown = (int)remain_value;
            else if(has_run) current_countdown = (int)run_value;
        }
        else if(strcmp(state_str, "WAIT_DONE") == 0)
        {
            current_countdown = 0;
        }
        else if(has_run || has_remain)
        {
            current_countdown = 0;
        }

        printf("countdown: %d\r\n", current_countdown);
    }
    else if(strstr(line, ",ERR,") != NULL)
    {
        printf("B reported an AGRI error\r\n");
    }
}
static void B_UART_Poll(void)
{
    while(USART_GetFlagStatus(USART3, USART_FLAG_RXNE) != RESET)
    {
        u8 data = (u8)USART_ReceiveData(USART3);

        if(B_UART_RxLen < (B_UART_RX_BUF_SIZE - 1))
        {
            B_UART_RxBuffer[B_UART_RxLen++] = data;
        }
        else
        {
            B_UART_RxLen = 0;
        }

        if(data == '\n')
        {
            while((B_UART_RxLen > 0U) &&
                  ((B_UART_RxBuffer[B_UART_RxLen - 1U] == '\r') ||
                   (B_UART_RxBuffer[B_UART_RxLen - 1U] == '\n')))
            {
                B_UART_RxLen--;
            }
            B_UART_RxBuffer[B_UART_RxLen] = '\0';
            AGRI_C_HandleLine((char *)B_UART_RxBuffer);
            B_UART_RxLen = 0;
        }
    }
}

static const char *AGRI_NormalizePlant(const char *plant)
{
    if(plant == NULL) return "Tomato";
    if(strcmp(plant, "Cactus") == 0) return "Cactus";
    if(strcmp(plant, "Lettuce") == 0) return "Lettuce";
    if(strcmp(plant, "Tomato") == 0) return "Tomato";
    return "Tomato";
}

void AGRI_C_Send_Manual(u16 run_s, const char *plant)
{
    char line[96];
    const char *plant_name = AGRI_NormalizePlant(plant);

    if(run_s > AGRI_MAX_RUN_S) run_s = AGRI_MAX_RUN_S;
    sprintf(line, "$AGRI,C,B,%04u,MANUAL,PLANT=%s,RUN=%u*00\r\n",
            AGRI_NextSeq(), plant_name, run_s);
    B_UART_SendText(line);
    printf("B UART TX: %s", line);
}

void AGRI_C_Send_Auto(u8 enable, const char *plant)
{
    char line[96];
    const char *plant_name = AGRI_NormalizePlant(plant);

    sprintf(line, "$AGRI,C,B,%04u,AUTO,ENABLE=%u,PLANT=%s*00\r\n",
            AGRI_NextSeq(), enable ? 1 : 0, plant_name);
    B_UART_SendText(line);
    printf("B UART TX: %s", line);
}

static void B_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART3, &USART_InitStructure);
    USART_Cmd(USART3, ENABLE);
}
/*********************************************************************
 * @fn      mStopIfError
 *
 * @brief   check if error.
 *
 * @param   iError - error constants.
 *
 * @return  none
 */
void mStopIfError(u8 iError)
{
    if (iError == WCHNET_ERR_SUCCESS)
        return;
    printf("Error: %02X\r\n", (u16) iError);
}

/*********************************************************************
 * @fn      TIM2_Init
 *
 * @brief   Initializes TIM2.
 *
 * @return  none
 */
void TIM2_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure = { 0 };

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseStructure.TIM_Period = SystemCoreClock / 1000000;
    TIM_TimeBaseStructure.TIM_Prescaler = WCHNETTIMERPERIOD * 1000 - 1;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

    TIM_Cmd(TIM2, ENABLE);
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    NVIC_EnableIRQ(TIM2_IRQn);
}

/*********************************************************************
 * @fn      WCHNET_CreateTcpSocketListen
 *
 * @brief   Create TCP Socket for Listening
 *
 * @return  none
 */
void WCHNET_CreateTcpSocketListen(void)
{
    u8 i;
    SOCK_INF TmpSocketInf;

    memset((void *) &TmpSocketInf, 0, sizeof(SOCK_INF));
    TmpSocketInf.SourPort = HTTP_SERVER_PORT;
    TmpSocketInf.ProtoType = PROTO_TYPE_TCP;
    i = WCHNET_SocketCreat(&SocketIdForListen, &TmpSocketInf);
    printf("SocketIdForListen %d\r\n", SocketIdForListen);
    mStopIfError(i);
    i = WCHNET_SocketListen(SocketIdForListen);
    mStopIfError(i);
}

/*********************************************************************
 * @fn      WCHNET_CreateCfgSocket
 *
 * @brief   According to the configuration information of the webpage,
 *          WCHNET establishes the corresponding socket.
 *
 *@param    mode - connection mode.
 *          Desip - destination IP
 *          Desport - destination port
 *          Srcport - source port
 * @return  none
 */
void WCHNET_CreateCfgSocket(u8 mode, u8 *Desip, u16 Desport, u16 Srcport)
{
    u8 i;
    SOCK_INF TmpSocketInf;

    memset((void *) &TmpSocketInf, 0, sizeof(SOCK_INF));
    printf("desport: %d, srcport: %d\n", Desport, Srcport);
    printf("desip:%d.%d.%d.%d\n", Desip[0], Desip[1], Desip[2], Desip[3]);
    printf("mode %d\n", mode);
    switch (mode) {
        case MODE_TCPSERVER:
            TmpSocketInf.ProtoType = PROTO_TYPE_TCP;
            TmpSocketInf.SourPort = Srcport;
            i = WCHNET_SocketCreat(&SocketId, &TmpSocketInf);
            mStopIfError(i);
            i = WCHNET_SocketListen(SocketId);
            mStopIfError(i);
            break;

        case MODE_TCPCLIENT:
            TmpSocketInf.ProtoType = PROTO_TYPE_TCP;
            memcpy((void *) &TmpSocketInf.IPAddr, Desip, 4);
            TmpSocketInf.SourPort = Srcport;
            TmpSocketInf.DesPort = Desport;
            TmpSocketInf.RecvBufLen = RECE_BUF_LEN;
            i = WCHNET_SocketCreat(&SocketId, &TmpSocketInf);
            mStopIfError(i);
            i = WCHNET_SocketConnect(SocketId);
            mStopIfError(i);
            break;

        default:
            break;
    }
}

/*********************************************************************
 * @fn      WCHNET_RestoreDefaults
 *
 * @brief   Parameter restore default value
 *
 * @return  none
 */
void WCHNET_RestoreDefaults(void)                                       /*WCHNET restore default settings*/
{
    WCHNET_GetMacAddr(&Basic_Default[2]);
    WEB_ERASE( PAGE_WRITE_START_ADDR, FLASH_PAGE_SIZE * 3);
    WEB_WRITE( BASIC_CFG_ADDR, Basic_Default, BASIC_CFG_LEN);
    WEB_WRITE( PORT_CFG_ADDR, Port_Default, PORT_CFG_LEN);
    WEB_WRITE( LOGIN_CFG_ADDR, Login_Default, LOGIN_CFG_LEN);
    NVIC_SystemReset();
}

/*********************************************************************
 * @fn      WCHNET_HandleSockInt
 *
 * @brief   Socket Interrupt Handle
 *
 * @param   socketid - socket id.
 *          intstat - interrupt status
 *
 * @return  none
 */
void WCHNET_HandleSockInt(u8 socketid, u8 intstat)
{
    u32 len;

    if (intstat & SINT_STAT_RECV)                                   //receive data
    {
        len = WCHNET_SocketRecvLen(socketid, NULL);
        if (SocketInf[socketid].SourPort == HTTP_SERVER_PORT) {     // receive HTTP data
            socket = socketid;
            WCHNET_SocketRecv(socketid, HTTPDataBuffer, &len);
            Web_Server();
        }
        else                                                        //receive the data of the configured socket
            WCHNET_SocketRecv(socketid, RecvBuffer, &len);
        printf("socketid:%d Received data length:%d\r\n",socketid, len);
    }
    if (intstat & SINT_STAT_CONNECT)                                //connect successfully
    {
        WCHNET_ModifyRecvBuf(socketid, (u32)SocketRecvBuf[socketid], RECE_BUF_LEN);
        printf("TCP Connect Success\r\n");
    }
    if (intstat & SINT_STAT_DISCONNECT)                             //disconnect
    {
        printf("TCP Disconnect\r\n");
    }
    if (intstat & SINT_STAT_TIM_OUT)                                //timeout disconnect
    {
        printf("TCP Timeout\r\n");
        WCHNET_CreateCfgSocket(Port_CfgBuf.mode, Port_CfgBuf.des_ip, DESPORT, SRCPORT);
    }
}

/*********************************************************************
 * @fn      WCHNET_HandleGlobalInt
 *
 * @brief   Global Interrupt Handle
 *
 * @return  none
 */
void WCHNET_HandleGlobalInt(void)
{
    u8 intstat;
    u16 i;
    u8 socketint;

    intstat = WCHNET_GetGlobalInt();                              //get global interrupt flag
    if (intstat & GINT_STAT_UNREACH)                              //Unreachable interrupt
    {
        printf("GINT_STAT_UNREACH\r\n");
    }
    if (intstat & GINT_STAT_IP_CONFLI)                            //IP conflict
    {
        printf("GINT_STAT_IP_CONFLI\r\n");
    }
    if (intstat & GINT_STAT_PHY_CHANGE)                           //PHY status change
    {
        i = WCHNET_GetPHYStatus();
        if (i & PHY_Linked_Status)
            printf("PHY Link Success\r\n");
    }
    if (intstat & GINT_STAT_SOCKET) {                             //socket related interrupt
        for (i = 0; i < WCHNET_MAX_SOCKET_NUM; i++) {
            socketint = WCHNET_GetSocketInt(i);
            if (socketint)
                WCHNET_HandleSockInt(i, socketint);
        }
    }
}

/*********************************************************************
 * @fn      GPIOInit
 *
 * @brief   GPIO initialization
 *
 * @return  none
 */
void GPIOInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = { 0 };
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program
 *
 * @return  none
 */
int main(void)
{
    u8 i;
    SystemCoreClockUpdate();
    Delay_Init();
    USART_Printf_Init(9600);                                                  //debug UART
    B_UART_Init();                                                              //B-C UART: USART3, 9600 8N1
    GPIOInit();
    printf("Web Server\r\n");
    printf("B-C UART: USART3 PB10/PB11, 9600 8N1\r\n");
    printf("SystemClk:%d\r\n", SystemCoreClock);
    printf("ChipID:%08x\r\n", DBGMCU_GetCHIPID());
    printf("net version:%x\n", WCHNET_GetVer());
    if (WCHNET_LIB_VER != WCHNET_GetVer()) {
        printf("version error.\n");
    }
    /*After the button(PB6) is pressed, initialize
     * WCHNET and execute the default configuration*/
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0) {
        Delay_Ms(100);
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0) {
            while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0);
            WCHNET_RestoreDefaults();
        }
    }
    WEB_READ( BASIC_CFG_ADDR, (u8 *)&Basic_CfgBuf, BASIC_CFG_LEN );                //Read configuration information
    WEB_READ( PORT_CFG_ADDR, (u8 *)&Port_CfgBuf, PORT_CFG_LEN );
    WEB_READ( LOGIN_CFG_ADDR, (u8 *)&Login_CfgBuf, LOGIN_CFG_LEN );
    /*Determine configuration information*/
    if(((Basic_CfgBuf.flag[0] != 0x57) || (Basic_CfgBuf.flag[1] != 0xAB)) ||\
       ((Port_CfgBuf.flag[0] != 0x57) || (Port_CfgBuf.flag[1] != 0xAB)) ||\
       ((Login_CfgBuf.flag[0] != 0x57) || (Login_CfgBuf.flag[1] != 0xAB)))
    {
        WCHNET_RestoreDefaults();
    }
    memcpy(MACAddr, Basic_CfgBuf.mac, 6);
    memcpy(IPAddr, Basic_CfgBuf.ip, 4);
    memcpy(IPMask, Basic_CfgBuf.mask, 4);
    memcpy(GWIPAddr, Basic_CfgBuf.gateway, 4);
    printf("ip: ");
    for (i = 0; i < 4; i++)
        printf("%d.", IPAddr[i]);
    printf("\n");

    printf("mac addr: ");
    for(i = 0; i < 6; i++) 
        printf("%x ", MACAddr[i]);
    printf("\n");
    TIM2_Init();
    i = ETH_LibInit(IPAddr, GWIPAddr, IPMask, MACAddr);                         //Ethernet library initialize
    mStopIfError(i);
    if (i == WCHNET_ERR_SUCCESS)
        printf("WCHNET_LibInit Success\r\n");
    WCHNET_CreateTcpSocketListen();                                             //Create  TCP Socket

    DESPORT = Port_CfgBuf.des_port[0] * 256 + Port_CfgBuf.des_port[1];
    SRCPORT = Port_CfgBuf.src_port[0] * 256 + Port_CfgBuf.src_port[1];
    WCHNET_CreateCfgSocket(Port_CfgBuf.mode, Port_CfgBuf.des_ip, DESPORT, SRCPORT);
    Init_Para_Tab();

    while(1)
    {
        B_UART_Poll();

        /*Ethernet library main task function,
         * which needs to be called cyclically*/
        WCHNET_MainTask();
        /*Query the Ethernet global interrupt,
         * if there is an interrupt, call the global interrupt handler*/
        if(WCHNET_QueryGlobalInt())
        {
            WCHNET_HandleGlobalInt();
        }
    }
}

