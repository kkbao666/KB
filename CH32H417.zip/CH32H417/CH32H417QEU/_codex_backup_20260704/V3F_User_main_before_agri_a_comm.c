#include "debug.h"
#include "irrigation_model.h"
#include "lora.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define B_A_NODE_ENABLE            1
#define B_AUTO_DEFAULT_ENABLE      1
#define B_C_REPORT_INTERVAL        200

#define C_UART                     USART3
#define C_UART_GPIO_PORT           GPIOB
#define C_UART_TX_PIN              GPIO_Pin_10
#define C_UART_TX_PIN_SOURCE       GPIO_PinSource10
#define C_UART_RX_PIN              GPIO_Pin_11
#define C_UART_RX_PIN_SOURCE       GPIO_PinSource11
#define C_UART_AF                  GPIO_AF7
#define C_UART_RX_BUF_SIZE         256

typedef struct
{
    uint32_t soil;
    uint32_t lux;
    uint32_t air_humidity;
    uint32_t air_temp;
    IrrigationPlantType plant;
    uint32_t run_s;
    uint32_t dur_s;
    char mode[8];
    char state[12];
} Agri_B_State;

static uint16_t agri_seq = 1;
static Agri_B_State agri_state = {
    0, 0,
    IRRIGATION_DEFAULT_AIR_HUMIDITY,
    IRRIGATION_DEFAULT_AIR_TEMP,
    IRRIGATION_DEFAULT_PLANT,
    0, 0, "AUTO", "IDLE"
};

static uint8_t c_uart_rx_buffer[C_UART_RX_BUF_SIZE];
static uint16_t c_uart_rx_len = 0;
static uint8_t c_uart_rx_complete = 0;
static uint8_t c_uart_rx_overflow = 0;
static uint8_t auto_mode_enabled = B_AUTO_DEFAULT_ENABLE;
static uint8_t a_link_status = 0;
static uint8_t c_link_status = 0;
static uint8_t command_active = 0;
static uint8_t countdown_active = 0;
static uint16_t active_cmd_seq = 0;
static uint32_t remaining_s = 0;
static uint32_t countdown_last_tick = 0;

static void C_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    RCC_HB2PeriphClockCmd(RCC_HB2Periph_AFIO | RCC_HB2Periph_GPIOB, ENABLE);
    RCC_HB1PeriphClockCmd(RCC_HB1Periph_USART3, ENABLE);

    GPIO_PinAFConfig(C_UART_GPIO_PORT, C_UART_TX_PIN_SOURCE, C_UART_AF);
    GPIO_InitStructure.GPIO_Pin = C_UART_TX_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Very_High;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(C_UART_GPIO_PORT, &GPIO_InitStructure);

    GPIO_PinAFConfig(C_UART_GPIO_PORT, C_UART_RX_PIN_SOURCE, C_UART_AF);
    GPIO_InitStructure.GPIO_Pin = C_UART_RX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(C_UART_GPIO_PORT, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(C_UART, &USART_InitStructure);
    USART_Cmd(C_UART, ENABLE);
}

static void C_UART_Clear_Rx(void)
{
    c_uart_rx_len = 0;
    c_uart_rx_complete = 0;
    c_uart_rx_overflow = 0;
}

static uint8_t C_UART_Receive_Check(void)
{
    while(USART_GetFlagStatus(C_UART, USART_FLAG_RXNE) != RESET)
    {
        uint8_t data = (uint8_t)USART_ReceiveData(C_UART);

        if(c_uart_rx_complete || c_uart_rx_overflow)
            continue;

        if(c_uart_rx_len < C_UART_RX_BUF_SIZE)
        {
            c_uart_rx_buffer[c_uart_rx_len++] = data;
            if(data == '\n') c_uart_rx_complete = 1;
        }
        else
        {
            c_uart_rx_overflow = 1;
        }
    }

    return c_uart_rx_complete || c_uart_rx_overflow;
}

static uint16_t C_UART_Read_Buffer(uint8_t *buffer, uint16_t max_len)
{
    uint16_t len = c_uart_rx_len;

    if(len > max_len) len = max_len;
    for(uint16_t i = 0; i < len; i++)
        buffer[i] = c_uart_rx_buffer[i];

    C_UART_Clear_Rx();
    return len;
}

static void C_UART_Send_Text(const char *text)
{
    while(*text)
    {
        USART_SendData(C_UART, (uint8_t)*text++);
        while(USART_GetFlagStatus(C_UART, USART_FLAG_TXE) == RESET);
    }

    while(USART_GetFlagStatus(C_UART, USART_FLAG_TC) == RESET);
}

static uint16_t Agri_Next_Seq(void)
{
    uint16_t seq = agri_seq++;
    if(agri_seq > 9999) agri_seq = 1;
    return seq;
}

static uint8_t Agri_Get_U32_Field(const char *line, const char *key, uint32_t *value)
{
    const char *p = strstr(line, key);
    uint32_t result = 0;
    uint8_t found_digit = 0;

    if(p == 0) return 0;
    p += strlen(key);
    if(*p != '=') return 0;
    p++;

    while((*p >= '0') && (*p <= '9'))
    {
        result = result * 10 + (uint32_t)(*p - '0');
        found_digit = 1;
        p++;
    }

    if(!found_digit) return 0;
    *value = result;
    return 1;
}

static uint8_t Agri_Get_Str_Field(const char *line, const char *key, char *value, uint8_t max_len)
{
    const char *p = strstr(line, key);
    uint8_t i = 0;

    if((p == 0) || (max_len == 0)) return 0;
    p += strlen(key);
    if(*p != '=') return 0;
    p++;

    while((*p != '\0') && (*p != ',') && (*p != '*') &&
          (i < (uint8_t)(max_len - 1)))
    {
        value[i++] = *p++;
    }

    value[i] = '\0';
    return (i > 0);
}

static uint16_t Agri_Get_Seq(const char *line)
{
    const char *p = line;
    uint16_t seq = 0;

    for(uint8_t i = 0; i < 3; i++)
    {
        p = strchr(p, ',');
        if(p == 0) return 0;
        p++;
    }

    while((*p >= '0') && (*p <= '9'))
    {
        seq = (uint16_t)(seq * 10 + (uint16_t)(*p - '0'));
        p++;
    }

    return seq;
}

static uint32_t Agri_Decide_Run(uint32_t soil,
                                uint32_t lux,
                                uint32_t air_humidity,
                                uint32_t air_temp,
                                IrrigationPlantType plant)
{
    IrrigationPrediction prediction;
    uint32_t seconds;

    prediction = Irrigation_Model_Predict((float)soil,
                                          (float)lux,
                                          (float)air_humidity,
                                          (float)air_temp,
                                          plant);

    if(!prediction.need_water)
        return 0;

    seconds = (uint32_t)(prediction.water_seconds + 0.5f);
    return seconds;
}

static uint32_t Agri_Run_Value(uint32_t run_s)
{
    return run_s;
}

static void Agri_Set_Mode_State(const char *mode, const char *state)
{
    strncpy(agri_state.mode, mode, sizeof(agri_state.mode) - 1);
    agri_state.mode[sizeof(agri_state.mode) - 1] = '\0';
    strncpy(agri_state.state, state, sizeof(agri_state.state) - 1);
    agri_state.state[sizeof(agri_state.state) - 1] = '\0';
}

static void Agri_Send_To_A(const char *text)
{
    (void)LoRa_Send_Buffer((const uint8_t *)text, (uint8_t)strlen(text));
}

static void Agri_Send_To_C(const char *text)
{
    C_UART_Send_Text(text);
}

static void Agri_Send_Ack_To_A(uint16_t seq, const char *type)
{
    char line[64];
    sprintf(line, "$AGRI,B,A,%04u,ACK,TYPE=%s*00\r\n", seq, type);
    Agri_Send_To_A(line);
}

static void Agri_Send_Ack_To_C(uint16_t seq, const char *type)
{
    char line[64];
    sprintf(line, "$AGRI,B,C,%04u,ACK,TYPE=%s*00\r\n", seq, type);
    Agri_Send_To_C(line);
}

static uint16_t Agri_Send_Cmd_To_A(const char *mode, uint32_t run_s)
{
    char line[80];
    uint16_t seq = Agri_Next_Seq();

    sprintf(line, "$AGRI,B,A,%04u,CMD,MODE=%s,RUN=%lu*00\r\n",
            seq, mode, (unsigned long)run_s);
    Agri_Send_To_A(line);
    return seq;
}

static void Agri_Send_Auto_Ack_To_C(uint16_t seq)
{
    char line[80];

    sprintf(line, "$AGRI,B,C,%04u,ACK,TYPE=AUTO,STATE=%s*00\r\n",
            seq, auto_mode_enabled ? "ENABLED" : "DISABLED");
    Agri_Send_To_C(line);
}

static void Agri_Send_Report_To_C(void)
{
    char line[256];

    sprintf(line,
            "$AGRI,B,C,%04u,RPT,AI=FLOAT_MLP,SOIL=%lu,LUX=%lu,HUM=%lu,TEMP=%lu,PLANT=%s,RUN=%lu,DUR=%lu,MODE=%s,STATE=%s,AUTO=%u,REMAIN=%lu,A_LINK=%u,C_LINK=%u*00\r\n",
            Agri_Next_Seq(),
            (unsigned long)agri_state.soil,
            (unsigned long)agri_state.lux,
            (unsigned long)agri_state.air_humidity,
            (unsigned long)agri_state.air_temp,
            Irrigation_Model_PlantName(agri_state.plant),
            (unsigned long)agri_state.run_s,
            (unsigned long)agri_state.dur_s,
            agri_state.mode,
            agri_state.state,
            (unsigned int)auto_mode_enabled,
            (unsigned long)remaining_s,
            (unsigned int)a_link_status,
            (unsigned int)c_link_status);

    Agri_Send_To_C(line);
}

static void Agri_Stop_Command_Tracking(void)
{
    command_active = 0;
    countdown_active = 0;
    active_cmd_seq = 0;
    remaining_s = 0;
}

static void Agri_Start_Countdown(void)
{
    remaining_s = agri_state.run_s;
    agri_state.dur_s = 0;
    countdown_active = (remaining_s > 0);
    countdown_last_tick = SysTick0->CNT;
}

static void Agri_Countdown_Tick(void)
{
    if(!countdown_active) return;

    if(remaining_s > 0) remaining_s--;
    agri_state.dur_s = agri_state.run_s - remaining_s;

    if(remaining_s == 0)
    {
        countdown_active = 0;
        Agri_Set_Mode_State(agri_state.mode, "WAIT_DONE");
    }

    Agri_Send_Report_To_C();
}

static void Agri_Timebase_Init(void)
{
    SysTick0->CTLR = 0;
    SysTick0->CNT = 0;
    SysTick0->CMP = 0xFFFFFFFFU;
    SysTick0->CTLR = (1U << 2) | (1U << 0);
}

static void Agri_Handle_Rx_Line(char *line)
{
    uint16_t rx_seq;
    uint8_t from_a;
    uint8_t from_c;
    uint32_t soil;
    uint32_t lux;
    uint32_t air_humidity;
    uint32_t air_temp;
    uint32_t manual_run;
    uint32_t auto_enable;
    uint32_t exec_run;
    uint32_t exec_dur;
    char ack_type[8];
    char exec_state[12];
    char plant_name[12];
    char error_line[96];

    from_a = (strstr(line, "$AGRI,A,B,") != 0);
    from_c = (strstr(line, "$AGRI,C,B,") != 0);
    if(!from_a && !from_c)
    {
        return;
    }

    if(from_a) a_link_status = 1;
    if(from_c) c_link_status = 1;
    rx_seq = Agri_Get_Seq(line);

    if(from_a && (strstr(line, ",SENS,") != 0))
    {
        Agri_Send_Ack_To_A(rx_seq, "SENS");

        air_humidity = 0;
        air_temp = 0;
        if(Agri_Get_U32_Field(line, "SOIL", &soil) &&
           Agri_Get_U32_Field(line, "LUX", &lux) &&
           (Agri_Get_U32_Field(line, "HUM", &air_humidity) ||
            Agri_Get_U32_Field(line, "HUMI", &air_humidity)) &&
           Agri_Get_U32_Field(line, "TEMP", &air_temp))
        {
            strcpy(plant_name, Irrigation_Model_PlantName(agri_state.plant));

            agri_state.soil = soil;
            agri_state.lux = lux;
            agri_state.air_humidity = air_humidity;
            agri_state.air_temp = air_temp;
            if(Agri_Get_Str_Field(line, "PLANT", plant_name, sizeof(plant_name)))
                agri_state.plant = Irrigation_Model_ParsePlant(plant_name);

            if(!command_active && auto_mode_enabled)
            {
                agri_state.run_s = Agri_Decide_Run(soil,
                                                   lux,
                                                   agri_state.air_humidity,
                                                   agri_state.air_temp,
                                                   agri_state.plant);
                agri_state.dur_s = 0;
                Agri_Set_Mode_State("AUTO",
                                   agri_state.run_s > 0 ? "WAIT_ACK" : "NO_WATER");

                if(agri_state.run_s > 0)
                {
                    active_cmd_seq = Agri_Send_Cmd_To_A("AUTO", agri_state.run_s);
                    command_active = 1;
                }
                else
                {
                    Agri_Stop_Command_Tracking();
                }
            }
            else if(!auto_mode_enabled)
            {
                Agri_Set_Mode_State("AUTO", "DISABLED");
            }

            Agri_Send_Report_To_C();
        }
        else
        {
            Agri_Send_To_A("$AGRI,B,A,0000,ERR,CODE=BAD_VALUE,MSG=SENS_FIELD*00\r\n");
            Agri_Set_Mode_State(agri_state.mode, "FAIL");
            Agri_Send_Report_To_C();
        }
    }
    else if(from_a && (strstr(line, ",EXEC,") != 0))
    {
        Agri_Send_Ack_To_A(rx_seq, "EXEC");

        if(Agri_Get_U32_Field(line, "RUN", &exec_run))
            agri_state.run_s = Agri_Run_Value(exec_run);
        if(Agri_Get_U32_Field(line, "DUR", &exec_dur))
            agri_state.dur_s = Agri_Run_Value(exec_dur);
        if(Agri_Get_Str_Field(line, "STATE", exec_state, sizeof(exec_state)))
            Agri_Set_Mode_State(agri_state.mode, exec_state);
        else
            Agri_Set_Mode_State(agri_state.mode, "DONE");

        Agri_Stop_Command_Tracking();
        Agri_Send_Report_To_C();
    }
    else if(from_c && (strstr(line, ",MANUAL,") != 0))
    {
        Agri_Send_Ack_To_C(rx_seq, "MANUAL");

        if(!Agri_Get_U32_Field(line, "RUN", &manual_run))
            manual_run = 0;

        if(Agri_Get_Str_Field(line, "PLANT", plant_name, sizeof(plant_name)))
            agri_state.plant = Irrigation_Model_ParsePlant(plant_name);

        auto_mode_enabled = 0;
        agri_state.run_s = Agri_Run_Value(manual_run);
        agri_state.dur_s = 0;
        Agri_Stop_Command_Tracking();

#if B_A_NODE_ENABLE
        Agri_Set_Mode_State("MANUAL", "WAIT_ACK");
        active_cmd_seq = Agri_Send_Cmd_To_A("MANUAL", agri_state.run_s);
        command_active = 1;
#else
        Agri_Set_Mode_State("MANUAL", "NO_A");
#endif
        Agri_Send_Report_To_C();
    }
    else if(from_c && (strstr(line, ",STOP") != 0))
    {
        Agri_Send_Ack_To_C(rx_seq, "STOP");
        auto_mode_enabled = 0;
        agri_state.run_s = 0;
        agri_state.dur_s = 0;
        Agri_Stop_Command_Tracking();

#if B_A_NODE_ENABLE
        Agri_Set_Mode_State("STOP", "WAIT_ACK");
        active_cmd_seq = Agri_Send_Cmd_To_A("MANUAL", 0);
        command_active = 1;
#else
        Agri_Set_Mode_State("STOP", "NO_A");
#endif
        Agri_Send_Report_To_C();
    }
    else if(from_c && (strstr(line, ",AUTO,") != 0))
    {
        if(Agri_Get_U32_Field(line, "ENABLE", &auto_enable))
        {
            auto_mode_enabled = (auto_enable != 0);
            if(Agri_Get_Str_Field(line, "PLANT", plant_name, sizeof(plant_name)))
                agri_state.plant = Irrigation_Model_ParsePlant(plant_name);
            if(!command_active)
            {
                Agri_Set_Mode_State("AUTO",
                                   auto_mode_enabled ? "WAIT_SENS" : "DISABLED");
            }
            Agri_Send_Auto_Ack_To_C(rx_seq);
            Agri_Send_Report_To_C();
        }
        else
        {
            sprintf(error_line,
                    "$AGRI,B,C,%04u,ERR,CODE=BAD_VALUE,MSG=AUTO_ENABLE*00\r\n",
                    rx_seq);
            Agri_Send_To_C(error_line);
        }
    }
    else if(from_c && (strstr(line, ",REQ,") != 0) &&
             (strstr(line, "TYPE=RPT") != 0))
    {
        Agri_Send_Ack_To_C(rx_seq, "REQ");
        Agri_Send_Report_To_C();
    }
    else if(from_a && (strstr(line, ",ACK,") != 0))
    {
        if(Agri_Get_Str_Field(line, "TYPE", ack_type, sizeof(ack_type)) &&
           (strcmp(ack_type, "CMD") == 0) &&
           command_active && (rx_seq == active_cmd_seq))
        {
            if(Agri_Get_Str_Field(line, "STATE", exec_state, sizeof(exec_state)))
                Agri_Set_Mode_State(agri_state.mode, exec_state);
            else
                Agri_Set_Mode_State(agri_state.mode, "EXEC");

            if(strcmp(agri_state.state, "EXEC") == 0)
                Agri_Start_Countdown();
            else if((strcmp(agri_state.state, "FAIL") == 0) ||
                    (strcmp(agri_state.state, "REJECT") == 0))
                Agri_Stop_Command_Tracking();

            Agri_Send_Report_To_C();
        }
    }
    else if(from_a && (strstr(line, ",ERR,") != 0))
    {
        Agri_Set_Mode_State(agri_state.mode, "FAIL");
        Agri_Stop_Command_Tracking();
        Agri_Send_Report_To_C();
    }
}

int main(void)
{
#if B_A_NODE_ENABLE
    uint8_t lora_recv_buf[LORA_RX_BUF_SIZE + 1];
#endif
    uint8_t c_recv_buf[C_UART_RX_BUF_SIZE + 1];
    uint16_t recv_len;
    uint16_t c_report_counter = 0;
    uint32_t now_tick;

    SystemInit();
    SystemAndCoreClockUpdate();
    Agri_Timebase_Init();

#if B_A_NODE_ENABLE
    LoRa_GPIO_Init();
    LoRa_UART_Init();
    LoRa_Set_Mode_Transparent();
    LoRa_Delay_Ms(100);
    LoRa_Clear_Rx();
#endif

    C_UART_Init();
    C_UART_Clear_Rx();

#if B_A_NODE_ENABLE
    Agri_Set_Mode_State("AUTO",
                       auto_mode_enabled ? "WAIT_SENS" : "DISABLED");
#else
    Agri_Set_Mode_State("AUTO", "NO_A");
#endif
    Agri_Send_Report_To_C();

    while(1)
    {
#if B_A_NODE_ENABLE
        if(LoRa_Receive_Check())
        {
            recv_len = LoRa_Read_Buffer(lora_recv_buf, LORA_RX_BUF_SIZE);
            lora_recv_buf[recv_len] = '\0';
            Agri_Handle_Rx_Line((char *)lora_recv_buf);
        }
#endif

        if(C_UART_Receive_Check())
        {
            recv_len = C_UART_Read_Buffer(c_recv_buf, C_UART_RX_BUF_SIZE);
            c_recv_buf[recv_len] = '\0';
            Agri_Handle_Rx_Line((char *)c_recv_buf);
        }

        now_tick = SysTick0->CNT;
        if(countdown_active &&
           ((uint32_t)(now_tick - countdown_last_tick) >= SystemCoreClock))
        {
            countdown_last_tick += SystemCoreClock;
            Agri_Countdown_Tick();
        }

        c_report_counter++;
        if(c_report_counter >= B_C_REPORT_INTERVAL)
        {
            c_report_counter = 0;
            Agri_Send_Report_To_C();
        }

        LoRa_Delay_Ms(10);
    }
}
