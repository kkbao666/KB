#ifndef IRRIGATION_MODEL_H
#define IRRIGATION_MODEL_H

#include <stdint.h>

#define IRRIGATION_DEFAULT_AIR_HUMIDITY 55U
#define IRRIGATION_DEFAULT_AIR_TEMP     28U
#define IRRIGATION_DEFAULT_PLANT        IRRIGATION_PLANT_TOMATO

typedef enum
{
    IRRIGATION_PLANT_CACTUS = 0,
    IRRIGATION_PLANT_LETTUCE = 1,
    IRRIGATION_PLANT_TOMATO = 2
} IrrigationPlantType;

typedef struct
{
    uint8_t need_water;
    float water_seconds;
    float need_water_score;
} IrrigationPrediction;

IrrigationPlantType Irrigation_Model_ParsePlant(const char *name);
const char *Irrigation_Model_PlantName(IrrigationPlantType plant);
IrrigationPrediction Irrigation_Model_Predict(float soil_moisture,
                                              float light,
                                              float air_humidity,
                                              float air_temp,
                                              IrrigationPlantType plant);

#endif
