#include "lora.h"

static volatile uint8_t lora_rx_buffer[LORA_RX_BUF_SIZE];
static volatile uint8_t lora_rx_len = 0;
static volatile uint8_t lora_rx_complete = 0;
static volatile uint8_t lora_rx_overflow = 0;

void LoRa_Delay_Ms(uint32_t ms)
{
    while(ms--)
    {
        for(volatile uint32_t i = 0; i < 40000; i++)
        {
            __asm volatile("nop");
        }
    }
}

void LoRa_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_HB2PeriphClockCmd(RCC_HB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = LORA_M0_PIN | LORA_M1_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Very_High;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(LORA_M0_PORT, &GPIO_InitStructure);

    LoRa_Set_Mode_Transparent();
}

void LoRa_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    RCC_HB2PeriphClockCmd(RCC_HB2Periph_AFIO | LORA_UART_GPIO_CLOCK, ENABLE);
    RCC_HB1PeriphClockCmd(RCC_HB1Periph_USART2, ENABLE);

    GPIO_PinAFConfig(LORA_UART_GPIO_PORT, LORA_UART_TX_PIN_SOURCE, LORA_UART_AF);
    GPIO_InitStructure.GPIO_Pin = LORA_UART_TX_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Very_High;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(LORA_UART_GPIO_PORT, &GPIO_InitStructure);

    GPIO_PinAFConfig(LORA_UART_GPIO_PORT, LORA_UART_RX_PIN_SOURCE, LORA_UART_AF);
    GPIO_InitStructure.GPIO_Pin = LORA_UART_RX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(LORA_UART_GPIO_PORT, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART2, &USART_InitStructure);

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    NVIC_SetPriority(USART2_IRQn, 1);
    NVIC_EnableIRQ(USART2_IRQn);

    USART_Cmd(USART2, ENABLE);
}

void LoRa_Set_Mode_Transparent(void)
{
    GPIO_ResetBits(LORA_M1_PORT, LORA_M1_PIN);
    GPIO_ResetBits(LORA_M0_PORT, LORA_M0_PIN);
    LoRa_Delay_Ms(10);
}

void LoRa_Set_Mode_Config(void)
{
    GPIO_ResetBits(LORA_M1_PORT, LORA_M1_PIN);
    GPIO_SetBits(LORA_M0_PORT, LORA_M0_PIN);
    LoRa_Delay_Ms(10);
}

void LoRa_Set_Mode_PowerSaving(void)
{
    GPIO_SetBits(LORA_M1_PORT, LORA_M1_PIN);
    GPIO_ResetBits(LORA_M0_PORT, LORA_M0_PIN);
    LoRa_Delay_Ms(10);
}

void LoRa_Set_Mode_DeepSleep(void)
{
    GPIO_SetBits(LORA_M1_PORT, LORA_M1_PIN);
    GPIO_SetBits(LORA_M0_PORT, LORA_M0_PIN);
    LoRa_Delay_Ms(10);
}

void LoRa_Send_Byte(uint8_t data)
{
    USART_SendData(USART2, data);
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
    {
    }
}

uint8_t LoRa_Send_Buffer(const uint8_t *buffer, uint16_t len)
{
    for(uint16_t i = 0; i < len; i++)
    {
        LoRa_Send_Byte(buffer[i]);
    }

    while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET)
    {
    }

    LoRa_Delay_Ms(LORA_TX_GUARD_MS);

    return LORA_OK;
}

void LoRa_Reset_Module(void)
{
    LoRa_Set_Mode_DeepSleep();
    LoRa_Delay_Ms(100);
    LoRa_Set_Mode_Transparent();
}

static uint8_t LoRa_Ends_With_Tail(void)
{
    return (lora_rx_len >= 3U) &&
           (lora_rx_buffer[lora_rx_len - 3U] == '*') &&
           (lora_rx_buffer[lora_rx_len - 2U] == '0') &&
           (lora_rx_buffer[lora_rx_len - 1U] == '0');
}

void USART2_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART2_IRQHandler(void)
{
    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        uint8_t data = (uint8_t)USART_ReceiveData(USART2);

        /* Ignore CR. Only LF or protocol tail *00 finishes a frame.
           This prevents CRLF from becoming two frames and prevents partial
           $AGRI packets from being processed too early. */
        if(data == '\r')
        {
            USART_ClearITPendingBit(USART2, USART_IT_RXNE);
            return;
        }

        if(data == '\n')
        {
            lora_rx_complete = 1;
            USART_ClearITPendingBit(USART2, USART_IT_RXNE);
            return;
        }

        if(lora_rx_len < LORA_RX_BUF_SIZE)
        {
            lora_rx_buffer[lora_rx_len++] = data;
            if(LoRa_Ends_With_Tail())
            {
                lora_rx_complete = 1;
            }
        }
        else
        {
            lora_rx_overflow = 1;
            lora_rx_complete = 1;
        }

        if(lora_rx_len >= LORA_RX_BUF_SIZE) lora_rx_complete = 1;
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
}

uint8_t LoRa_Receive_Check(void)
{
    return lora_rx_complete || lora_rx_overflow;
}

uint16_t LoRa_Read_Buffer(uint8_t *buffer, uint16_t max_len)
{
    uint16_t len;

    NVIC_DisableIRQ(USART2_IRQn);
    len = lora_rx_len;
    if(len > max_len) len = max_len;

    for(uint16_t i = 0; i < len; i++)
    {
        buffer[i] = lora_rx_buffer[i];
    }

    lora_rx_len = 0;
    lora_rx_complete = 0;
    lora_rx_overflow = 0;
    NVIC_EnableIRQ(USART2_IRQn);

    return len;
}

void LoRa_Clear_Rx(void)
{
    NVIC_DisableIRQ(USART2_IRQn);
    lora_rx_len = 0;
    lora_rx_complete = 0;
    lora_rx_overflow = 0;
    NVIC_EnableIRQ(USART2_IRQn);
}
