#ifndef LORA_H
#define LORA_H

#include <stdint.h>
#include "ch32h417.h"

#define LORA_OK                     0

#define LORA_M0_PORT                GPIOB
#define LORA_M0_PIN                 GPIO_Pin_0
#define LORA_M1_PORT                GPIOB
#define LORA_M1_PIN                 GPIO_Pin_1

#define LORA_UART_GPIO_PORT         GPIOA
#define LORA_UART_GPIO_CLOCK        RCC_HB2Periph_GPIOA
#define LORA_UART_TX_PIN            GPIO_Pin_2
#define LORA_UART_TX_PIN_SOURCE     GPIO_PinSource2
#define LORA_UART_RX_PIN            GPIO_Pin_3
#define LORA_UART_RX_PIN_SOURCE     GPIO_PinSource3
#define LORA_UART_AF                GPIO_AF7

#define LORA_RX_BUF_SIZE            256
#define LORA_TX_GUARD_MS            80

void LoRa_GPIO_Init(void);
void LoRa_UART_Init(void);
void LoRa_Set_Mode_Transparent(void);
void LoRa_Set_Mode_Config(void);
void LoRa_Set_Mode_PowerSaving(void);
void LoRa_Set_Mode_DeepSleep(void);
void LoRa_Delay_Ms(uint32_t ms);
void LoRa_Send_Byte(uint8_t data);
uint8_t LoRa_Send_Buffer(const uint8_t *buffer, uint16_t len);
void LoRa_Reset_Module(void);
uint8_t LoRa_Receive_Check(void);
uint16_t LoRa_Read_Buffer(uint8_t *buffer, uint16_t max_len);
void LoRa_Clear_Rx(void);

#endif
